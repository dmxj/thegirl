echo "运行结束咯～"

pm2 stop ./bin/www